-- Top 10 Customers by Revenue
SELECT Customer_Name, SUM(Sales) Revenue
FROM Orders
GROUP BY Customer_Name
ORDER BY Revenue DESC
LIMIT 10;

-- Category-wise Sales
SELECT Category, SUM(Sales) Total_Sales
FROM Orders
GROUP BY Category;

-- Monthly Revenue
SELECT YEAR(Order_Date) Yr, MONTH(Order_Date) Mn, SUM(Sales) Revenue
FROM Orders
GROUP BY YEAR(Order_Date), MONTH(Order_Date);

-- Region Performance
SELECT Region, SUM(Sales) Sales, SUM(Profit) Profit
FROM Orders
GROUP BY Region;

-- Top States by Revenue
SELECT State, SUM(Sales) Revenue
FROM Orders
GROUP BY State
ORDER BY Revenue DESC;
